const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const sequelize = require('./src/models/db');
const app = express();
const dotenv = require('dotenv');
dotenv.config();
const https = require("https");


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());

//const poRoute = require('./src/routes/po.routes');
//const userRoute = require('./src/routes/user.routes');
//const supplierRoute = require('./src/routes/supplier.routes');
const schroute = require('./src/routes/stj_schedule.routes');

//app.use('/newvms/po', poRoute);
//app.use(cors('/newvms/user', userRoute));
//app.use('/newvms/supplier', supplierRoute);
app.use('/stj', schroute);

sequelize.sync().then(() => {
	app.listen(3200, () => {
		console.log('Server is running on port 3200');
	});
});

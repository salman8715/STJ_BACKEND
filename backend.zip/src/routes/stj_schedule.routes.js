const express = require('express');
const router = express.Router();

const schcontrollers = require('../controllers/sch.controllers');

router.get('/getsch', schcontrollers.getallsch);

module.exports = router;

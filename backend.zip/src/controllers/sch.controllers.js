const { query } = require('express');

const schedule = require('../models/stj_schedule.models');


async function getallsch(req, res, next) {
	const page = req.query.page || 1; // Current page number
	const limit = req.query.limit || 10;
	schedule.findAll({
	limit,
    attributes:['tanggal', 'type_unit', 'driver', 'customer', 'muat_loc', 'bongkar_loc', 'status']})
		.then((data) => {
				res.json({
					code: 0,
					message: "ok",
					type: "success",
					result: data, page, limit,
				 });
                 //console.log(data);
				
		})
		.catch((error) => {
			res.status(400).json({
				error
			});
		});
}


module.exports = {
getallsch
};